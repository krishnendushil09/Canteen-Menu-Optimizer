# Canteen Menu Optimizer (Modern UI)
Full Flask app with pastel gradient UI and animations.
